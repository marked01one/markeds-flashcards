$(document).ready(function() {
    $('.groups').on('click', function() {
      $('.groups').toggleClass('visible');
    });
  });